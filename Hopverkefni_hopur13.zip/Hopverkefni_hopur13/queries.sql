-- Flestir victories

--view með lista yfir bardagana
create view fight_list as
select s1.name as name1, wins1, s2.name as name2, wins2
from supers s1,
     supers s2,
     fights
where super1_id = s1.id
  and super2_id = s2.id
group by s1.name, s2.name, wins1, wins2

--view með name1 og sigrum
create view name1_wins as
select name1 as name, count(wins1) as wins
from fight_list ff
where wins1 > wins2
group by name1
order by count(wins1) desc;

--view með name2 og sigrum
create view name2_wins as
select name2 as name, count(wins2) as wins
from fight_list ff
where wins2 > wins1
group by name2
order by count(wins2) desc;

------
select s.name, (sum(n1.wins) + sum(n2.wins)) as wins
from name1_wins n1,
     name2_wins n2,
     supers s
where n1.name = s.name
  and n2.name = s.name
group by s.name
order by (sum(n1.wins) + sum(n2.wins)) desc
------


-- Mesti PURE victories
--view með name1 og pure wins
create view name1_wins_pure as
select name1 as name, count(wins1) as wins
from fight_list ff
where wins2 = 0
group by name1
order by count(wins1) desc;

--view með name2 og pure wins
create view name2_wins_pure as
select name2 as name, count(wins2) as wins
from fight_list ff
where wins1 = 0
group by name2
order by count(wins2) desc;

-----------
select s.name, (sum(n1.wins) + sum(n2.wins)) as wins
from name1_wins_pure n1,
     name2_wins_pure n2,
     supers s
where n1.name = s.name
  and n2.name = s.name
group by s.name
order by (sum(n1.wins) + sum(n2.wins)) desc
-------------


-- Mesti PURE defeats
--view með name1 og pure defeats
create view name1_defeats_pure as
select name1 as name, count(wins1) as loss
from fight_list ff
where wins1 = 0
group by name1
order by count(wins1) desc;

--view með name2 og pure defeats
create view name2_defeats_pure as
select name2 as name, count(wins2) as loss
from fight_list ff
where wins2 = 0
group by name2
order by count(wins2) desc;

----------
select s.name, (sum(n1.loss) + sum(n2.loss)) as Losses
from name1_defeats_pure n1,
     name2_defeats_pure n2,
     supers s
where n1.name = s.name
  and n2.name = s.name
group by s.name
order by (sum(n1.loss) + sum(n2.loss)) desc
------------

-- Mest defeats
--view með name1 og defeats
create view name1_defeats as
select name1 as name, count(wins1) as loss
from fight_list ff
where wins1 < wins2
group by name1
order by count(wins1) desc;

--view með name2 og defeats
create view name2_defeats as
select name2 as name, count(wins2) as loss
from fight_list ff
where wins2 < wins1
group by name2
order by count(wins2) desc;

--Amount of powers
--view þar sem fjöldi krafta kemur fram á hverja hetju
create view powers_count as
select s.name, count(p.id) as powers
from powers p,
     link_power l,
     supers s
where p.id = l.power_id
  and l.super_id = s.id
group by s.name
order by count(p.id) desc;


--kvk vs kk
--Tafla þar sem mismunandi upplýsingar um karl hetjur vs kvenn hetjur koma fram
select BMI.gender,
       round(BMI."Average BMI", 2)        as "Average BMI",
       round(BMI."Standard Deviation", 2) AS "STD",
       round(PERC.WINS, 2)                as "Win Rate [%]",
       tt.avg                             as "Average powers"

from (select s.gender,
             avg(1.0 * s.weight / ((s.height / 100.0) ^ 2))    AS "Average BMI",
             stddev(1.0 * s.weight / ((s.height / 100.0) ^ 2)) AS "Standard Deviation"
      from supers as s
      where (s.gender = 'male' or s.gender = 'female')
        and s.weight != 0
        and s.height != 0
      group by s.gender) as BMI,

     (select s.gender,
             round(1.0 * (sum(f.wins1)) / (count(distinct (s.gender)) * count(s.id) * num.N * 1.0) * 100.0, 2) as WINS
      from supers as s,
           fights as f,
           (select (wins1 + wins2) as N
            from fights
            where id = 1) as num
      where s.id = f.super1_id
        and (s.gender = 'male' or s.gender = 'female')
      group by s.gender, num.N) as PERC,
     (select distinct s.gender, round(sum(t.powers) / count(s.id), 2) as avg
      from supers s,
           link_power l,
           powers p,
           (
               select s.name, count(p.id) as powers
               from powers p,
                    link_power l,
                    supers s
               where p.id = l.power_id
                 and l.super_id = s.id
               group by s.name, s.gender
               order by count(p.id) desc) t
      where p.id = l.power_id
        and l.super_id = s.id
        and t.name = s.name
        and (s.gender = 'male' or s.gender = 'female')
      group by s.gender) tt

WHERE PERC.gender = BMI.gender
  and tt.gender = BMI.gender
GROUP BY BMI.gender, BMI."Average BMI", BMI."Standard Deviation", PERC.WINS, tt.avg



--Total fights
--view með einni tölu þar sem fjöldi fights kemur fram
create view fights_count as
select count(s.id) as total
from supers s;

--Tafla með samantekt af wins,pure wins, losses, pure losses, win ratio og fjöldi krafta fyrir hverja hetju
select s.name                                                                             as hero,
       coalesce((sum(n111.wins) + sum(n222.wins)), sum(n111.wins), sum(n222.wins), 0)     as wins,
       coalesce((sum(n1111.wins) + sum(n2222.wins)), sum(n1111.wins), sum(n2222.wins), 0) as pure_wins,
       coalesce((sum(n1.loss) + sum(n2.loss)), sum(n1.loss), sum(n2.loss), 0)             as Losses,
       coalesce((sum(n11.loss) + sum(n22.loss)), sum(n11.loss), sum(n22.loss), 0)         as pure_losses,
       round(((coalesce((sum(n111.wins) + sum(n222.wins)), sum(n111.wins), sum(n222.wins), 0)) / (f.total - 1) * 100),
             2)                                                                           as win_ratio,
       p.powers                                                                           as powers

from supers s
         full outer join name1_defeats n1 on n1.name = s.name
         left outer join name2_defeats n2 on n2.name = s.name
         left outer join name1_defeats_pure n11 on n11.name = s.name
         left outer join name2_defeats_pure n22 on n22.name = s.name
         left outer join name1_wins n111 on n111.name = s.name
         left outer join name2_wins n222 on n222.name = s.name
         left outer join name1_wins_pure n1111 on n1111.name = s.name
         left outer join name2_wins_pure n2222 on n2222.name = s.name,
     powers_count p,
     fights_count f
where p.name = s.name
group by s.name, powers, f.total
--having s.name = ''
order by losses desc;


--Algengustu kraftarnir hjá top 10 hetjunum
select distinct pp.power, count(pp.id)
from (select s.name                                                                             as hero,
             coalesce((sum(n111.wins) + sum(n222.wins)), sum(n111.wins), sum(n222.wins), 0)     as wins,
             coalesce((sum(n1111.wins) + sum(n2222.wins)), sum(n1111.wins), sum(n2222.wins), 0) as pure_wins,
             coalesce((sum(n1.loss) + sum(n2.loss)), sum(n1.loss), sum(n2.loss), 0)             as Losses,
             coalesce((sum(n11.loss) + sum(n22.loss)), sum(n11.loss), sum(n22.loss), 0)         as pure_losses,
             round(((coalesce((sum(n111.wins) + sum(n222.wins)), sum(n111.wins), sum(n222.wins), 0)) / (f.total - 1) *
                    100), 2)                                                                    as win_ratio,
             p.powers                                                                           as powers

      from supers s
               full outer join name1_defeats n1 on n1.name = s.name
               left outer join name2_defeats n2 on n2.name = s.name
               left outer join name1_defeats_pure n11 on n11.name = s.name
               left outer join name2_defeats_pure n22 on n22.name = s.name
               left outer join name1_wins n111 on n111.name = s.name
               left outer join name2_wins n222 on n222.name = s.name
               left outer join name1_wins_pure n1111 on n1111.name = s.name
               left outer join name2_wins_pure n2222 on n2222.name = s.name,
           powers_count p,
           fights_count f
      where p.name = s.name
      group by s.name, powers, f.total
--having s.name = ''
      order by losses desc
      limit 10
     ) t,
     supers ss,
     link_power ll,
     powers pp
where t.hero = ss.name
  and ll.super_id = ss.id
  and pp.id = ll.power_id
group by pp.power
order by count(pp.id) desc
limit 10;

--algengustu kraftarnir overall
select p.power, count(p.id), round((100.0 * count(p.id) / f.total), 2) as percentage
from powers p,
     link_power l,
     supers s,
     fights_count f
where p.id = l.power_id
  and l.super_id = s.id
group by p.power, f.total
order by count(p.id) desc
limit 10;


--Tafla með upplýsingum um publishera, hlutfall ofurhetja frá þeim, kk og kvk, sigurhlutfall, og fjölda krafta
--TAFLA 3: PUBLISHER

SELECT s.publisher,
       ROUND(hero_ratio, 2)     AS hero_ratio,
       ROUND(win_ratio, 2)      AS win_ratio,
       ROUND(percent_male, 2)   AS percent_male,
       ROUND(percent_female, 2) AS percent_female,
       ROUND(avg_nr_powers, 2)  AS avg_nr_powers
FROM supers s
         --PUBLISHER: HERO RATIO
         LEFT OUTER JOIN

     (SELECT s.publisher,
             100.0 * COUNT(s.id) / (SELECT COUNT(s1.id)
                                    FROM supers s1) AS hero_ratio
      FROM supers s
      GROUP BY s.publisher) AS s1 ON s1.publisher = s.publisher

         LEFT OUTER JOIN
     --PUBLISHER: WIN RATIO

         (SELECT s.publisher,
                 AVG(100.0 * hero_wins.wins / (SELECT COUNT(s1.id) - 1
                                               FROM supers s1)) AS win_ratio
          FROM supers s,
               (select s.name, (sum(n1.wins) + sum(n2.wins)) as wins
                from (select name1 as name, count(wins1) as wins
                      from fight_list ff
                      where wins1 > wins2
                      group by name1

                      order by count(wins1) desc) n1,
                     (select name2 as name, count(wins2) as wins
                      from fight_list ff
                      where wins2 > wins1
                      group by name2
                      order by count(wins2) desc) as n2,
                     supers s
                where n1.name = s.name
                  and n2.name = s.name
                group by s.name
                order by (sum(n1.wins) + sum(n2.wins)) desc) AS hero_wins
          WHERE s.name = hero_wins.name
          GROUP BY s.publisher) AS s2 ON s2.publisher = s.publisher

         LEFT OUTER JOIN
     --PUBLISHER: MALE RATIO

         (SELECT s.publisher,
                 100.0 * COUNT(s.id) / (SELECT COUNT(s1.id)
                                        FROM supers s1
                                        WHERE s.publisher = s1.publisher) AS percent_male
          FROM supers s
          WHERE s.gender = 'male'
          GROUP BY s.publisher) AS s3 ON s3.publisher = s.publisher

         LEFT OUTER JOIN
     --PUBLISHER: FEMALE RATIO

         (SELECT s.publisher,
                 100.0 * COUNT(s.id) / (SELECT COUNT(s1.id)
                                        FROM supers s1
                                        WHERE s.publisher = s1.publisher) AS percent_female
          FROM supers s
          WHERE s.gender = 'female'
          GROUP BY s.publisher) AS s4 ON s4.publisher = s.publisher

         LEFT OUTER JOIN
     --PUBLISHER: AVG POWERS/HEROES:

         (SELECT s.publisher,
                 AVG(hero_powers.nr_powers) AS avg_nr_powers
          FROM supers s,
               (SELECT s.name, COUNT(p.id) AS nr_powers
                FROM supers s,
                     link_power lp,
                     powers p
                WHERE s.id = lp.super_id
                  AND lp.power_id = p.id
                GROUP BY s.name) AS hero_powers
          WHERE s.name = hero_powers.name
          GROUP BY s.publisher) AS s5 ON s5.publisher = s.publisher
GROUP BY s.publisher, hero_ratio, win_ratio, percent_male, percent_female, avg_nr_powers
ORDER BY hero_ratio DESC, win_ratio DESC
LIMIT 10;

-- Reyna að skoða hvort ákveðnir kraftar gera ofurhetjur líklegri til að sigra
select p.power,
       ROUND(100.0 * (COALESCE(sum(n1.wins), 0) + COALESCE(sum(n2.wins), 0)) /
             (COALESCE(sum(n1.wins), 0) + COALESCE(sum(n2.wins), 0) + COALESCE(sum(n1.losses), 0) +
              COALESCE(sum(n2.losses), 0))) AS win_perc,
       COUNT(s.id)                          AS nr_heroes
from (select name1 as name, sum(wins1) as wins, sum(wins2) as losses
      from fight_list ff
      where wins1 > wins2
      group by name1
      order by count(wins1) desc) n1,
     (select name2 as name, sum(wins2) as wins, sum(wins1) as losses
      from fight_list ff
      where wins2 > wins1
      group by name2
      order by count(wins2) desc) as n2,
     supers s,
     link_power lp,
     powers p
where n1.name = s.name
  and n2.name = s.name
  and s.id = lp.super_id
  and lp.power_id = p.id
group by p.power
HAVING COUNT(s.id) > 4
order by win_perc DESC, nr_heroes DESC

--Tafla með upplýsingum um mennskar ofurhetjur með flesta krafta
select s.name, s.race, s.gender, s.hair_color, s.eye_color, count(p.power) as powers
from supers s,
     link_power l,
     powers p
where s.id = l.super_id
  and l.power_id = p.id
group by s.name, s.gender, s.race, s.eye_color, s.hair_color
having race = 'human'
order by count(p.power) desc
limit 10;