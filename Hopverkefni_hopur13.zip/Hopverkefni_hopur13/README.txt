
Fengum "super_hero_powers.csv" héðan:

https://www.kaggle.com/claudiodavi/superhero-set#heroes_information.csv

Fengum "SuperheroDataset.csv" héðan:

https://www.kaggle.com/thec03u5/complete-superhero-dataset